/*******************************************************************************************************************
Copyright (c) 2023 Cycling '74

The code that Max generates automatically and that end users are capable of
exporting and using, and any associated documentation files (the “Software”)
is a work of authorship for which Cycling '74 is the author and owner for
copyright purposes.

This Software is dual-licensed either under the terms of the Cycling '74
License for Max-Generated Code for Export, or alternatively under the terms
of the General Public License (GPL) Version 3. You may use the Software
according to either of these licenses as it is most appropriate for your
project on a case-by-case basis (proprietary or not).

A) Cycling '74 License for Max-Generated Code for Export

A license is hereby granted, free of charge, to any person obtaining a copy
of the Software (“Licensee”) to use, copy, modify, merge, publish, and
distribute copies of the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following conditions:

The Software is licensed to Licensee for all uses that do not include the sale,
sublicensing, or commercial distribution of software that incorporates this
source code. This means that the Licensee is free to use this software for
educational, research, and prototyping purposes, to create musical or other
creative works with software that incorporates this source code, or any other
use that does not constitute selling software that makes use of this source
code. Commercial distribution also includes the packaging of free software with
other paid software, hardware, or software-provided commercial services.

For entities with UNDER $200k in annual revenue or funding, a license is hereby
granted, free of charge, for the sale, sublicensing, or commercial distribution
of software that incorporates this source code, for as long as the entity's
annual revenue remains below $200k annual revenue or funding.

For entities with OVER $200k in annual revenue or funding interested in the
sale, sublicensing, or commercial distribution of software that incorporates
this source code, please send inquiries to licensing@cycling74.com.

The above copyright notice and this license shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Please see
https://support.cycling74.com/hc/en-us/articles/10730637742483-RNBO-Export-Licensing-FAQ
for additional information

B) General Public License Version 3 (GPLv3)
Details of the GPLv3 license can be found at: https://www.gnu.org/licenses/gpl-3.0.html
*******************************************************************************************************************/

#ifdef RNBO_LIB_PREFIX
#define STR_IMPL(A) #A
#define STR(A) STR_IMPL(A)
#define RNBO_LIB_INCLUDE(X) STR(RNBO_LIB_PREFIX/X)
#else
#define RNBO_LIB_INCLUDE(X) #X
#endif // RNBO_LIB_PREFIX
#ifdef RNBO_INJECTPLATFORM
#define RNBO_USECUSTOMPLATFORM
#include RNBO_INJECTPLATFORM
#endif // RNBO_INJECTPLATFORM

#include RNBO_LIB_INCLUDE(RNBO_Common.h)
#include RNBO_LIB_INCLUDE(RNBO_AudioSignal.h)

namespace RNBO {


#define trunc(x) ((Int)(x))
#define autoref auto&

#if defined(__GNUC__) || defined(__clang__)
    #define RNBO_RESTRICT __restrict__
#elif defined(_MSC_VER)
    #define RNBO_RESTRICT __restrict
#endif

#define FIXEDSIZEARRAYINIT(...) { }

template <class ENGINE = INTERNALENGINE> class rnbomatic : public PatcherInterfaceImpl {

friend class EngineCore;
friend class Engine;
friend class MinimalEngine<>;
public:

rnbomatic()
: _internalEngine(this)
{
}

~rnbomatic()
{
    deallocateSignals();
}

Index getNumMidiInputPorts() const {
    return 0;
}

void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}

Index getNumMidiOutputPorts() const {
    return 0;
}

void process(
    const SampleValue * const* inputs,
    Index numInputs,
    SampleValue * const* outputs,
    Index numOutputs,
    Index n
) {
    RNBO_UNUSED(numInputs);
    RNBO_UNUSED(inputs);
    this->vs = n;
    this->updateTime(this->getEngine()->getCurrentTime(), (ENGINE*)nullptr, true);
    SampleValue * out1 = (numOutputs >= 1 && outputs[0] ? outputs[0] : this->dummyBuffer);
    SampleValue * out2 = (numOutputs >= 2 && outputs[1] ? outputs[1] : this->dummyBuffer);

    this->gen_01_perform(
        this->gen_01_in1,
        this->gen_01_speed_min,
        this->gen_01_speed_max,
        this->gen_01_ding_duration,
        this->gen_01_speed,
        this->gen_01_bell_trig,
        this->gen_01_volume_out,
        this->gen_01_clack_duration,
        this->signals[0],
        n
    );

    this->signalforwarder_01_perform(this->signals[0], out2, n);
    this->signalforwarder_02_perform(this->signals[0], out1, n);
    this->stackprotect_perform(n);
    this->globaltransport_advance();
    this->advanceTime((ENGINE*)nullptr);
    this->audioProcessSampleCount += this->vs;
}

void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
    RNBO_ASSERT(this->_isInitialized);

    if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
        Index i;

        for (i = 0; i < 1; i++) {
            this->signals[i] = resizeSignal(this->signals[i], this->maxvs, maxBlockSize);
        }

        this->globaltransport_tempo = resizeSignal(this->globaltransport_tempo, this->maxvs, maxBlockSize);
        this->globaltransport_state = resizeSignal(this->globaltransport_state, this->maxvs, maxBlockSize);
        this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
        this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
        this->didAllocateSignals = true;
    }

    const bool sampleRateChanged = sampleRate != this->sr;
    const bool maxvsChanged = maxBlockSize != this->maxvs;
    const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;

    if (sampleRateChanged || maxvsChanged) {
        this->vs = maxBlockSize;
        this->maxvs = maxBlockSize;
        this->sr = sampleRate;
        this->invsr = 1 / sampleRate;
    }

    this->gen_01_dspsetup(forceDSPSetup);
    this->globaltransport_dspsetup(forceDSPSetup);

    if (sampleRateChanged)
        this->onSampleRateChanged(sampleRate);
}

number msToSamps(MillisecondTime ms, number sampleRate) {
    return ms * sampleRate * 0.001;
}

MillisecondTime sampsToMs(SampleIndex samps) {
    return samps * (this->invsr * 1000);
}

Index getNumInputChannels() const {
    return 0;
}

Index getNumOutputChannels() const {
    return 2;
}

DataRef* getDataRef(DataRefIndex index)  {
    switch (index) {
    case 0:
        {
        return addressOf(this->RNBODefaultSinus);
        break;
        }
    default:
        {
        return nullptr;
        }
    }
}

DataRefIndex getNumDataRefs() const {
    return 1;
}

void processDataViewUpdate(DataRefIndex index, MillisecondTime time) {
    this->updateTime(time, (ENGINE*)nullptr);

    if (index == 0) {
        this->gen_01_cycle_38_buffer = reInitDataView(this->gen_01_cycle_38_buffer, this->RNBODefaultSinus);
        this->gen_01_cycle_41_buffer = reInitDataView(this->gen_01_cycle_41_buffer, this->RNBODefaultSinus);
        this->gen_01_cycle_44_buffer = reInitDataView(this->gen_01_cycle_44_buffer, this->RNBODefaultSinus);
        this->gen_01_cycle_66_buffer = reInitDataView(this->gen_01_cycle_66_buffer, this->RNBODefaultSinus);
        this->gen_01_cycle_71_buffer = reInitDataView(this->gen_01_cycle_71_buffer, this->RNBODefaultSinus);
        this->gen_01_cycle_76_buffer = reInitDataView(this->gen_01_cycle_76_buffer, this->RNBODefaultSinus);
    }
}

void initialize() {
    RNBO_ASSERT(!this->_isInitialized);

    this->RNBODefaultSinus = initDataRef(
        this->RNBODefaultSinus,
        this->dataRefStrings->name0,
        true,
        this->dataRefStrings->file0,
        this->dataRefStrings->tag0
    );

    this->assign_defaults();
    this->applyState();
    this->RNBODefaultSinus->setIndex(0);
    this->gen_01_cycle_38_buffer = new SampleBuffer(this->RNBODefaultSinus);
    this->gen_01_cycle_41_buffer = new SampleBuffer(this->RNBODefaultSinus);
    this->gen_01_cycle_44_buffer = new SampleBuffer(this->RNBODefaultSinus);
    this->gen_01_cycle_66_buffer = new SampleBuffer(this->RNBODefaultSinus);
    this->gen_01_cycle_71_buffer = new SampleBuffer(this->RNBODefaultSinus);
    this->gen_01_cycle_76_buffer = new SampleBuffer(this->RNBODefaultSinus);
    this->initializeObjects();
    this->allocateDataRefs();
    this->startup();
    this->_isInitialized = true;
}

void getPreset(PatcherStateInterface& preset) {
    this->updateTime(this->getEngine()->getCurrentTime(), (ENGINE*)nullptr);
    preset["__presetid"] = "rnbo";
    this->param_01_getPresetValue(getSubState(preset, "volume_out"));
    this->param_02_getPresetValue(getSubState(preset, "speed_min"));
    this->param_03_getPresetValue(getSubState(preset, "speed_max"));
    this->param_04_getPresetValue(getSubState(preset, "speed"));
    this->param_05_getPresetValue(getSubState(preset, "clack_duration"));
    this->param_06_getPresetValue(getSubState(preset, "ding_duration"));
    this->param_07_getPresetValue(getSubState(preset, "bell_trig"));
}

void setPreset(MillisecondTime time, PatcherStateInterface& preset) {
    this->updateTime(time, (ENGINE*)nullptr);
    this->param_01_setPresetValue(getSubState(preset, "volume_out"));
    this->param_02_setPresetValue(getSubState(preset, "speed_min"));
    this->param_03_setPresetValue(getSubState(preset, "speed_max"));
    this->param_04_setPresetValue(getSubState(preset, "speed"));
    this->param_05_setPresetValue(getSubState(preset, "clack_duration"));
    this->param_06_setPresetValue(getSubState(preset, "ding_duration"));
    this->param_07_setPresetValue(getSubState(preset, "bell_trig"));
}

void setParameterValue(ParameterIndex index, ParameterValue v, MillisecondTime time) {
    this->updateTime(time, (ENGINE*)nullptr);

    switch (index) {
    case 0:
        {
        this->param_01_value_set(v);
        break;
        }
    case 1:
        {
        this->param_02_value_set(v);
        break;
        }
    case 2:
        {
        this->param_03_value_set(v);
        break;
        }
    case 3:
        {
        this->param_04_value_set(v);
        break;
        }
    case 4:
        {
        this->param_05_value_set(v);
        break;
        }
    case 5:
        {
        this->param_06_value_set(v);
        break;
        }
    case 6:
        {
        this->param_07_value_set(v);
        break;
        }
    }
}

void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
    this->setParameterValue(index, value, time);
}

void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
    this->setParameterValue(index, this->getParameterValue(index), time);
}

void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
    this->setParameterValueNormalized(index, value, time);
}

ParameterValue getParameterValue(ParameterIndex index)  {
    switch (index) {
    case 0:
        {
        return this->param_01_value;
        }
    case 1:
        {
        return this->param_02_value;
        }
    case 2:
        {
        return this->param_03_value;
        }
    case 3:
        {
        return this->param_04_value;
        }
    case 4:
        {
        return this->param_05_value;
        }
    case 5:
        {
        return this->param_06_value;
        }
    case 6:
        {
        return this->param_07_value;
        }
    default:
        {
        return 0;
        }
    }
}

ParameterIndex getNumSignalInParameters() const {
    return 0;
}

ParameterIndex getNumSignalOutParameters() const {
    return 0;
}

ParameterIndex getNumParameters() const {
    return 7;
}

ConstCharPointer getParameterName(ParameterIndex index) const {
    switch (index) {
    case 0:
        {
        return "volume_out";
        }
    case 1:
        {
        return "speed_min";
        }
    case 2:
        {
        return "speed_max";
        }
    case 3:
        {
        return "speed";
        }
    case 4:
        {
        return "clack_duration";
        }
    case 5:
        {
        return "ding_duration";
        }
    case 6:
        {
        return "bell_trig";
        }
    default:
        {
        return "bogus";
        }
    }
}

ConstCharPointer getParameterId(ParameterIndex index) const {
    switch (index) {
    case 0:
        {
        return "volume_out";
        }
    case 1:
        {
        return "speed_min";
        }
    case 2:
        {
        return "speed_max";
        }
    case 3:
        {
        return "speed[1]";
        }
    case 4:
        {
        return "clack_duration";
        }
    case 5:
        {
        return "ding_duration";
        }
    case 6:
        {
        return "bell_trig";
        }
    default:
        {
        return "bogus";
        }
    }
}

void getParameterInfo(ParameterIndex index, ParameterInfo * info) const {
    {
        switch (index) {
        case 0:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = 0;
            info->max = 1;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "";
            info->unit = "";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 1:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = 0;
            info->max = 9999;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "";
            info->unit = "";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 2:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = 0;
            info->max = 9999;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "";
            info->unit = "";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 3:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = 0;
            info->max = 9999;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "";
            info->unit = "";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 4:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = 0;
            info->max = 1;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "";
            info->unit = "";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 5:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = 0;
            info->max = 1;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "";
            info->unit = "";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 6:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = 0;
            info->max = 1;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "";
            info->unit = "";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        }
    }
}

ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
    if (steps == 1) {
        if (normalizedValue > 0) {
            normalizedValue = 1.;
        }
    } else {
        ParameterValue oneStep = (number)1. / (steps - 1);
        ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
        normalizedValue = numberOfSteps * oneStep;
    }

    return normalizedValue;
}

ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
    switch (index) {
    case 0:
    case 4:
    case 5:
    case 6:
        {
        {
            value = (value < 0 ? 0 : (value > 1 ? 1 : value));
            ParameterValue normalizedValue = (value - 0) / (1 - 0);
            return normalizedValue;
        }
        }
    case 1:
    case 2:
    case 3:
        {
        {
            value = (value < 0 ? 0 : (value > 9999 ? 9999 : value));
            ParameterValue normalizedValue = (value - 0) / (9999 - 0);
            return normalizedValue;
        }
        }
    default:
        {
        return value;
        }
    }
}

ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
    value = (value < 0 ? 0 : (value > 1 ? 1 : value));

    switch (index) {
    case 0:
    case 4:
    case 5:
    case 6:
        {
        {
            {
                return 0 + value * (1 - 0);
            }
        }
        }
    case 1:
    case 2:
    case 3:
        {
        {
            {
                return 0 + value * (9999 - 0);
            }
        }
        }
    default:
        {
        return value;
        }
    }
}

ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
    switch (index) {
    case 0:
        {
        return this->param_01_value_constrain(value);
        }
    case 1:
        {
        return this->param_02_value_constrain(value);
        }
    case 2:
        {
        return this->param_03_value_constrain(value);
        }
    case 3:
        {
        return this->param_04_value_constrain(value);
        }
    case 4:
        {
        return this->param_05_value_constrain(value);
        }
    case 5:
        {
        return this->param_06_value_constrain(value);
        }
    case 6:
        {
        return this->param_07_value_constrain(value);
        }
    default:
        {
        return value;
        }
    }
}

void processNumMessage(MessageTag , MessageTag , MillisecondTime , number ) {}

void processListMessage(MessageTag , MessageTag , MillisecondTime , const list& ) {}

void processBangMessage(MessageTag , MessageTag , MillisecondTime ) {}

MessageTagInfo resolveTag(MessageTag tag) const {
    switch (tag) {

    }

    return "";
}

MessageIndex getNumMessages() const {
    return 0;
}

const MessageInfo& getMessageInfo(MessageIndex index) const {
    switch (index) {

    }

    return NullMessageInfo;
}

protected:

		
void advanceTime(EXTERNALENGINE*) {}
void advanceTime(INTERNALENGINE*) {
	_internalEngine.advanceTime(sampstoms(this->vs));
}

void processInternalEvents(MillisecondTime time) {
	_internalEngine.processEventsUntil(time);
}

void updateTime(MillisecondTime time, INTERNALENGINE*, bool inProcess = false) {
	if (time == TimeNow) time = getPatcherTime();
	processInternalEvents(inProcess ? time + sampsToMs(this->vs) : time);
	updateTime(time, (EXTERNALENGINE*)nullptr);
}

rnbomatic* operator->() {
    return this;
}
const rnbomatic* operator->() const {
    return this;
}
rnbomatic* getTopLevelPatcher() {
    return this;
}

void cancelClockEvents()
{
}

template<typename LISTTYPE = list> void listquicksort(LISTTYPE& arr, LISTTYPE& sortindices, Int l, Int h, bool ascending) {
    if (l < h) {
        Int p = (Int)(this->listpartition(arr, sortindices, l, h, ascending));
        this->listquicksort(arr, sortindices, l, p - 1, ascending);
        this->listquicksort(arr, sortindices, p + 1, h, ascending);
    }
}

template<typename LISTTYPE = list> Int listpartition(LISTTYPE& arr, LISTTYPE& sortindices, Int l, Int h, bool ascending) {
    number x = arr[(Index)h];
    Int i = (Int)(l - 1);

    for (Int j = (Int)(l); j <= h - 1; j++) {
        bool asc = (bool)((bool)(ascending) && arr[(Index)j] <= x);
        bool desc = (bool)((bool)(!(bool)(ascending)) && arr[(Index)j] >= x);

        if ((bool)(asc) || (bool)(desc)) {
            i++;
            this->listswapelements(arr, i, j);
            this->listswapelements(sortindices, i, j);
        }
    }

    i++;
    this->listswapelements(arr, i, h);
    this->listswapelements(sortindices, i, h);
    return i;
}

template<typename LISTTYPE = list> void listswapelements(LISTTYPE& arr, Int a, Int b) {
    auto tmp = arr[(Index)a];
    arr[(Index)a] = arr[(Index)b];
    arr[(Index)b] = tmp;
}

Index voice() {
    return this->_voiceIndex;
}

number random(number low, number high) {
    number range = high - low;
    return globalrandom() * range + low;
}

number wrap(number x, number low, number high) {
    number lo;
    number hi;

    if (low == high)
        return low;

    if (low > high) {
        hi = low;
        lo = high;
    } else {
        lo = low;
        hi = high;
    }

    number range = hi - lo;

    if (x >= lo && x < hi)
        return x;

    if (range <= 0.000000001)
        return lo;

    Int numWraps = (Int)(trunc((x - lo) / range));
    numWraps = numWraps - ((x < lo ? 1 : 0));
    number result = x - range * numWraps;

    if (result >= hi)
        return result - range;
    else
        return result;
}

inline number linearinterp(number frac, number x, number y) {
    return x + (y - x) * frac;
}

inline number cubicinterp(number a, number w, number x, number y, number z) {
    number a1 = 1. + a;
    number aa = a * a1;
    number b = 1. - a;
    number b1 = 2. - a;
    number bb = b * b1;
    number fw = -.1666667 * bb * a;
    number fx = .5 * bb * a1;
    number fy = .5 * aa * b1;
    number fz = -.1666667 * aa * b;
    return w * fw + x * fx + y * fy + z * fz;
}

inline number fastcubicinterp(number a, number w, number x, number y, number z) {
    number a2 = a * a;
    number f0 = z - y - w + x;
    number f1 = w - x - f0;
    number f2 = y - w;
    number f3 = x;
    return f0 * a * a2 + f1 * a2 + f2 * a + f3;
}

inline number splineinterp(number a, number w, number x, number y, number z) {
    number a2 = a * a;
    number f0 = -0.5 * w + 1.5 * x - 1.5 * y + 0.5 * z;
    number f1 = w - 2.5 * x + 2 * y - 0.5 * z;
    number f2 = -0.5 * w + 0.5 * y;
    return f0 * a * a2 + f1 * a2 + f2 * a + x;
}

inline number spline6interp(number a, number y0, number y1, number y2, number y3, number y4, number y5) {
    number ym2py2 = y0 + y4;
    number ym1py1 = y1 + y3;
    number y2mym2 = y4 - y0;
    number y1mym1 = y3 - y1;
    number sixthym1py1 = (number)1 / (number)6.0 * ym1py1;
    number c0 = (number)1 / (number)120.0 * ym2py2 + (number)13 / (number)60.0 * ym1py1 + (number)11 / (number)20.0 * y2;
    number c1 = (number)1 / (number)24.0 * y2mym2 + (number)5 / (number)12.0 * y1mym1;
    number c2 = (number)1 / (number)12.0 * ym2py2 + sixthym1py1 - (number)1 / (number)2.0 * y2;
    number c3 = (number)1 / (number)12.0 * y2mym2 - (number)1 / (number)6.0 * y1mym1;
    number c4 = (number)1 / (number)24.0 * ym2py2 - sixthym1py1 + (number)1 / (number)4.0 * y2;
    number c5 = (number)1 / (number)120.0 * (y5 - y0) + (number)1 / (number)24.0 * (y1 - y4) + (number)1 / (number)12.0 * (y3 - y2);
    return ((((c5 * a + c4) * a + c3) * a + c2) * a + c1) * a + c0;
}

inline number cosT8(number r) {
    number t84 = 56.0;
    number t83 = 1680.0;
    number t82 = 20160.0;
    number t81 = 2.4801587302e-05;
    number t73 = 42.0;
    number t72 = 840.0;
    number t71 = 1.9841269841e-04;

    if (r < 0.785398163397448309615660845819875721 && r > -0.785398163397448309615660845819875721) {
        number rr = r * r;
        return 1.0 - rr * t81 * (t82 - rr * (t83 - rr * (t84 - rr)));
    } else if (r > 0.0) {
        r -= 1.57079632679489661923132169163975144;
        number rr = r * r;
        return -r * (1.0 - t71 * rr * (t72 - rr * (t73 - rr)));
    } else {
        r += 1.57079632679489661923132169163975144;
        number rr = r * r;
        return r * (1.0 - t71 * rr * (t72 - rr * (t73 - rr)));
    }
}

inline number cosineinterp(number frac, number x, number y) {
    number a2 = (1.0 - this->cosT8(frac * 3.14159265358979323846)) / (number)2.0;
    return x * (1.0 - a2) + y * a2;
}

inline number intnum(const number value) {
    return trunc(value);
}

number minimum(number x, number y) {
    return (y < x ? y : x);
}

inline number safediv(number num, number denom) {
    return (denom == 0.0 ? 0.0 : num / denom);
}

number safepow(number base, number exponent) {
    return fixnan(rnbo_pow(base, exponent));
}

number scale(
    number x,
    number lowin,
    number hiin,
    number lowout,
    number highout,
    number pow
) {
    auto inscale = this->safediv(1., hiin - lowin);
    number outdiff = highout - lowout;
    number value = (x - lowin) * inscale;

    if (pow != 1) {
        if (value > 0)
            value = this->safepow(value, pow);
        else
            value = -this->safepow(-value, pow);
    }

    value = value * outdiff + lowout;
    return value;
}

number maximum(number x, number y) {
    return (x < y ? y : x);
}

number mstosamps(MillisecondTime ms) {
    return ms * this->sr * 0.001;
}

MillisecondTime sampstoms(number samps) {
    return samps * 1000 / this->sr;
}

void param_01_value_set(number v) {
    v = this->param_01_value_constrain(v);
    this->param_01_value = v;
    this->sendParameter(0, false);

    if (this->param_01_value != this->param_01_lastValue) {
        this->getEngine()->presetTouched();
        this->param_01_lastValue = this->param_01_value;
    }

    this->gen_01_volume_out_set(v);
}

void param_02_value_set(number v) {
    v = this->param_02_value_constrain(v);
    this->param_02_value = v;
    this->sendParameter(1, false);

    if (this->param_02_value != this->param_02_lastValue) {
        this->getEngine()->presetTouched();
        this->param_02_lastValue = this->param_02_value;
    }

    this->gen_01_speed_min_set(v);
}

void param_03_value_set(number v) {
    v = this->param_03_value_constrain(v);
    this->param_03_value = v;
    this->sendParameter(2, false);

    if (this->param_03_value != this->param_03_lastValue) {
        this->getEngine()->presetTouched();
        this->param_03_lastValue = this->param_03_value;
    }

    this->gen_01_speed_max_set(v);
}

void param_04_value_set(number v) {
    v = this->param_04_value_constrain(v);
    this->param_04_value = v;
    this->sendParameter(3, false);

    if (this->param_04_value != this->param_04_lastValue) {
        this->getEngine()->presetTouched();
        this->param_04_lastValue = this->param_04_value;
    }

    this->gen_01_speed_set(v);
}

void param_05_value_set(number v) {
    v = this->param_05_value_constrain(v);
    this->param_05_value = v;
    this->sendParameter(4, false);

    if (this->param_05_value != this->param_05_lastValue) {
        this->getEngine()->presetTouched();
        this->param_05_lastValue = this->param_05_value;
    }

    this->gen_01_clack_duration_set(v);
}

void param_06_value_set(number v) {
    v = this->param_06_value_constrain(v);
    this->param_06_value = v;
    this->sendParameter(5, false);

    if (this->param_06_value != this->param_06_lastValue) {
        this->getEngine()->presetTouched();
        this->param_06_lastValue = this->param_06_value;
    }

    this->gen_01_ding_duration_set(v);
}

void param_07_value_set(number v) {
    v = this->param_07_value_constrain(v);
    this->param_07_value = v;
    this->sendParameter(6, false);

    if (this->param_07_value != this->param_07_lastValue) {
        this->getEngine()->presetTouched();
        this->param_07_lastValue = this->param_07_value;
    }

    this->gen_01_bell_trig_set(v);
}

MillisecondTime getPatcherTime() const {
    return this->_currentTime;
}

void deallocateSignals() {
    Index i;

    for (i = 0; i < 1; i++) {
        this->signals[i] = freeSignal(this->signals[i]);
    }

    this->globaltransport_tempo = freeSignal(this->globaltransport_tempo);
    this->globaltransport_state = freeSignal(this->globaltransport_state);
    this->zeroBuffer = freeSignal(this->zeroBuffer);
    this->dummyBuffer = freeSignal(this->dummyBuffer);
}

Index getMaxBlockSize() const {
    return this->maxvs;
}

number getSampleRate() const {
    return this->sr;
}

bool hasFixedVectorSize() const {
    return false;
}

void setProbingTarget(MessageTag ) {}

void fillRNBODefaultSinus(DataRef& ref) {
    SampleBuffer buffer(ref);
    number bufsize = buffer->getSize();

    for (Index i = 0; i < bufsize; i++) {
        buffer[i] = rnbo_cos(i * 3.14159265358979323846 * 2. / bufsize);
    }
}

void fillDataRef(DataRefIndex index, DataRef& ref) {
    switch (index) {
    case 0:
        {
        this->fillRNBODefaultSinus(ref);
        break;
        }
    }
}

void allocateDataRefs() {
    this->gen_01_cycle_38_buffer->requestSize(16384, 1);
    this->gen_01_cycle_38_buffer->setSampleRate(this->sr);
    this->gen_01_cycle_41_buffer->requestSize(16384, 1);
    this->gen_01_cycle_41_buffer->setSampleRate(this->sr);
    this->gen_01_cycle_44_buffer->requestSize(16384, 1);
    this->gen_01_cycle_44_buffer->setSampleRate(this->sr);
    this->gen_01_cycle_66_buffer->requestSize(16384, 1);
    this->gen_01_cycle_66_buffer->setSampleRate(this->sr);
    this->gen_01_cycle_71_buffer->requestSize(16384, 1);
    this->gen_01_cycle_71_buffer->setSampleRate(this->sr);
    this->gen_01_cycle_76_buffer->requestSize(16384, 1);
    this->gen_01_cycle_76_buffer->setSampleRate(this->sr);
    this->gen_01_cycle_38_buffer = this->gen_01_cycle_38_buffer->allocateIfNeeded();
    this->gen_01_cycle_41_buffer = this->gen_01_cycle_41_buffer->allocateIfNeeded();
    this->gen_01_cycle_44_buffer = this->gen_01_cycle_44_buffer->allocateIfNeeded();
    this->gen_01_cycle_66_buffer = this->gen_01_cycle_66_buffer->allocateIfNeeded();
    this->gen_01_cycle_71_buffer = this->gen_01_cycle_71_buffer->allocateIfNeeded();
    this->gen_01_cycle_76_buffer = this->gen_01_cycle_76_buffer->allocateIfNeeded();

    if (this->RNBODefaultSinus->hasRequestedSize()) {
        if (this->RNBODefaultSinus->wantsFill())
            this->fillRNBODefaultSinus(this->RNBODefaultSinus);

        this->getEngine()->sendDataRefUpdated(0);
    }
}

void initializeObjects() {
    this->gen_01_history_1_init();
    this->gen_01_history_2_init();
    this->gen_01_history_3_init();
    this->gen_01_history_4_init();
    this->gen_01_noise_0_init();
    this->gen_01_noise_12_init();
    this->gen_01_noise_15_init();
    this->gen_01_change_88_init();
    this->gen_01_latch_96_init();
    this->gen_01_latch_109_init();
}

Index getIsMuted()  {
    return this->isMuted;
}

void setIsMuted(Index v)  {
    this->isMuted = v;
}

void onSampleRateChanged(double ) {}

void extractState(PatcherStateInterface& ) {}

void applyState() {}

void processClockEvent(MillisecondTime , ClockId , bool , ParameterValue ) {}

void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}

void processOutletEvent(
    EngineLink* sender,
    OutletIndex index,
    ParameterValue value,
    MillisecondTime time
) {
    this->updateTime(time, (ENGINE*)nullptr);
    this->processOutletAtCurrentTime(sender, index, value);
}

void sendOutlet(OutletIndex index, ParameterValue value) {
    this->getEngine()->sendOutlet(this, index, value);
}

void startup() {
    this->updateTime(this->getEngine()->getCurrentTime(), (ENGINE*)nullptr);

    {
        this->scheduleParamInit(0, 0);
    }

    {
        this->scheduleParamInit(1, 0);
    }

    {
        this->scheduleParamInit(2, 0);
    }

    {
        this->scheduleParamInit(3, 0);
    }

    {
        this->scheduleParamInit(4, 0);
    }

    {
        this->scheduleParamInit(5, 0);
    }

    {
        this->scheduleParamInit(6, 0);
    }

    this->processParamInitEvents();
}

number param_01_value_constrain(number v) const {
    v = (v > 1 ? 1 : (v < 0 ? 0 : v));
    return v;
}

number gen_01_volume_out_constrain(number v) const {
    if (v < 0)
        v = 0;

    if (v > 1)
        v = 1;

    return v;
}

void gen_01_volume_out_set(number v) {
    v = this->gen_01_volume_out_constrain(v);
    this->gen_01_volume_out = v;
}

number param_02_value_constrain(number v) const {
    v = (v > 9999 ? 9999 : (v < 0 ? 0 : v));
    return v;
}

number gen_01_speed_min_constrain(number v) const {
    if (v < 0)
        v = 0;

    if (v > 9999)
        v = 9999;

    return v;
}

void gen_01_speed_min_set(number v) {
    v = this->gen_01_speed_min_constrain(v);
    this->gen_01_speed_min = v;
}

number param_03_value_constrain(number v) const {
    v = (v > 9999 ? 9999 : (v < 0 ? 0 : v));
    return v;
}

number gen_01_speed_max_constrain(number v) const {
    if (v < 0)
        v = 0;

    if (v > 9999)
        v = 9999;

    return v;
}

void gen_01_speed_max_set(number v) {
    v = this->gen_01_speed_max_constrain(v);
    this->gen_01_speed_max = v;
}

number param_04_value_constrain(number v) const {
    v = (v > 9999 ? 9999 : (v < 0 ? 0 : v));
    return v;
}

number gen_01_speed_constrain(number v) const {
    if (v < 0)
        v = 0;

    if (v > 9999)
        v = 9999;

    return v;
}

void gen_01_speed_set(number v) {
    v = this->gen_01_speed_constrain(v);
    this->gen_01_speed = v;
}

number param_05_value_constrain(number v) const {
    v = (v > 1 ? 1 : (v < 0 ? 0 : v));
    return v;
}

number gen_01_clack_duration_constrain(number v) const {
    if (v < 0)
        v = 0;

    if (v > 1)
        v = 1;

    return v;
}

void gen_01_clack_duration_set(number v) {
    v = this->gen_01_clack_duration_constrain(v);
    this->gen_01_clack_duration = v;
}

number param_06_value_constrain(number v) const {
    v = (v > 1 ? 1 : (v < 0 ? 0 : v));
    return v;
}

number gen_01_ding_duration_constrain(number v) const {
    if (v < 0)
        v = 0;

    if (v > 1)
        v = 1;

    return v;
}

void gen_01_ding_duration_set(number v) {
    v = this->gen_01_ding_duration_constrain(v);
    this->gen_01_ding_duration = v;
}

number param_07_value_constrain(number v) const {
    v = (v > 1 ? 1 : (v < 0 ? 0 : v));
    return v;
}

number gen_01_bell_trig_constrain(number v) const {
    if (v < 0)
        v = 0;

    if (v > 1)
        v = 1;

    return v;
}

void gen_01_bell_trig_set(number v) {
    v = this->gen_01_bell_trig_constrain(v);
    this->gen_01_bell_trig = v;
}

void gen_01_perform(
    number in1,
    number speed_min,
    number speed_max,
    number ding_duration,
    number speed,
    number bell_trig,
    number volume_out,
    number clack_duration,
    SampleValue * out1,
    Index n
) {
    RNBO_UNUSED(speed_min);
    RNBO_UNUSED(in1);
    auto __gen_01_history_2_value = this->gen_01_history_2_value;
    auto __gen_01_history_1_value = this->gen_01_history_1_value;
    auto __gen_01_history_4_value = this->gen_01_history_4_value;
    auto __gen_01_history_3_value = this->gen_01_history_3_value;
    number volume_6_2 = volume_out;
    auto int_7_3 = this->intnum(4000);
    number mul_8_4 = 3.14159265358979323846 * -2;
    number mul_9_5 = mul_8_4 * int_7_3;
    number div_10_6 = (this->sr == 0. ? 0. : mul_9_5 / this->sr);
    number exp_11_7 = rnbo_exp(div_10_6);
    number speed_max_19_17 = speed_max;
    number clack_duration_25_23 = clack_duration;
    auto int_28_26 = this->intnum(4);
    number speed_29_27 = speed;
    number speed_30_28 = speed_29_27;
    auto min_31_29 = this->minimum(speed_30_28, speed_max_19_17);
    number div_32_30 = (speed_max_19_17 == 0. ? 0. : min_31_29 / speed_max_19_17);
    number speed_normalized_33_31 = div_32_30;
    number speed_normalized_34_32 = speed_normalized_33_31;
    auto scale_35_33 = this->scale(speed_normalized_34_32, 0, 1, 0.01, 0.02, 1);
    number speed_normalized_36_34 = speed_normalized_33_31;
    number speed_normalized_38_36 = speed_normalized_33_31;
    auto scale_39_37 = this->scale(speed_normalized_38_36, 0, 1, 100, 200, 1);
    number speed_normalized_48_46 = speed_normalized_33_31;
    number mul_49_47 = speed_normalized_48_46 * 0.2;
    number speed_normalized_51_49 = speed_normalized_33_31;
    number speed_normalized_54_52 = speed_normalized_33_31;
    number mul_55_53 = speed_normalized_54_52 * speed_normalized_54_52;
    number ding_duration_58_56 = ding_duration;
    number speed_normalized_59_57 = speed_normalized_33_31;
    number mul_60_58 = speed_normalized_59_57 * 66;
    number add_61_59 = int_28_26 + mul_60_58;
    number mul_65_64 = add_61_59 * 0.1;
    number add_66_65 = mul_65_64 + 0.5;
    number mul_71_70 = add_61_59 * 2;
    number mul_76_75 = add_61_59 * 10;
    number abs_92_92 = rnbo_abs(ding_duration_58_56);
    number abs_104_106 = rnbo_abs(clack_duration_25_23);
    number pass_115_118 = speed_29_27;
    number mul_118_123 = speed_29_27 * 1.5;
    Index i;

    for (i = 0; i < (Index)n; i++) {
        number noise_5_1 = this->gen_01_noise_0_next();
        number mix_12_8 = noise_5_1 + exp_11_7 * (__gen_01_history_3_value - noise_5_1);
        number float_13_9 = float(0.9);
        number float_14_10 = float(0.45);
        number float_15_11 = float(0.02);
        number noise_16_13 = this->gen_01_noise_12_next();
        number float_17_14 = float(0.2);
        number noise_18_16 = this->gen_01_noise_15_next();
        number sqrt_20_18 = rnbo_sqrt(2);
        number sqrt_21_19 = rnbo_sqrt(1.5);
        number float_22_20 = float(0.3);
        number float_23_21 = float(0.5);
        number float_24_22 = float(0.2);
        number pass_26_24 = noise_5_1;
        number sub_27_25 = pass_26_24 - mix_12_8;
        number mul_37_35 = float_14_10 * speed_normalized_33_31;
        number cycle_40 = 0;
        number cycleindex_41 = 0;
        array<number, 2> result_39 = this->gen_01_cycle_38_next(scale_39_37, 0);
        cycleindex_41 = result_39[1];
        cycle_40 = result_39[0];
        number mul_42_40 = scale_39_37 * sqrt_20_18;
        number cycle_43 = 0;
        number cycleindex_44 = 0;
        array<number, 2> result_42 = this->gen_01_cycle_41_next(mul_42_40, 0);
        cycleindex_44 = result_42[1];
        cycle_43 = result_42[0];
        number mul_45_43 = scale_39_37 * sqrt_21_19;
        number cycle_46 = 0;
        number cycleindex_47 = 0;
        array<number, 2> result_45 = this->gen_01_cycle_44_next(mul_45_43, 0);
        cycleindex_47 = result_45[1];
        cycle_46 = result_45[0];
        number add_50_48 = float_15_11 + mul_49_47;
        number mul_52_50 = float_22_20 * speed_normalized_51_49;
        number mul_53_51 = noise_16_13 * mul_52_50;
        number mul_56_54 = float_24_22 * mul_55_53;
        number mul_57_55 = noise_18_16 * mul_56_54;
        number phasor_62_61 = this->gen_01_phasor_60_next(add_61_59, 0);
        number lt_63_62 = phasor_62_61 < float_13_9;
        number mul_64_63 = lt_63_62 * mul_37_35;
        number cycle_67 = 0;
        number cycleindex_68 = 0;
        array<number, 2> result_67 = this->gen_01_cycle_66_next(add_66_65, 0);
        cycleindex_68 = result_67[1];
        cycle_67 = result_67[0];
        number mul_69_68 = cycle_67 * add_50_48;
        number add_70_69 = mul_64_63 + mul_69_68;
        number cycle_72 = 0;
        number cycleindex_73 = 0;
        array<number, 2> result_72 = this->gen_01_cycle_71_next(mul_71_70, 0);
        cycleindex_73 = result_72[1];
        cycle_72 = result_72[0];
        number abs_74_73 = rnbo_abs(cycle_72);
        number mul_75_74 = abs_74_73 * mul_53_51;
        number cycle_77 = 0;
        number cycleindex_78 = 0;
        array<number, 2> result_77 = this->gen_01_cycle_76_next(mul_76_75, 0);
        cycleindex_78 = result_77[1];
        cycle_77 = result_77[0];
        number abs_79_78 = rnbo_abs(cycle_77);
        number mul_80_79 = float_23_21 * abs_79_78;
        number add_81_80 = float_17_14 + mul_80_79;
        number mul_82_81 = add_81_80 * mul_57_55;
        number add_83_82 = mul_75_74 + mul_82_81;
        number add_84_83 = add_70_69 + add_83_82;
        number mix_85_84 = __gen_01_history_4_value + scale_35_33 * (add_84_83 - __gen_01_history_4_value);
        number mul_86_85 = mix_85_84 * (cycle_40 + cycle_46 + cycle_43);
        number mul_87_86 = mul_86_85 * speed_normalized_36_34;
        number tanh_88_87 = rnbo_tanh(mul_87_86);
        number change_89_89 = this->gen_01_change_88_next(bell_trig);
        number gt_90_90 = change_89_89 > 0;
        number bell_trig_91_91 = gt_90_90;
        number mul_93_93 = abs_92_92 * bell_trig_91_91;
        number mul_94_94 = mul_93_93 * this->sr;
        number latch_95_97 = this->gen_01_latch_96_next(mul_94_94, bell_trig_91_91);
        number switch_96_98 = ((bool)(mul_94_94) ? mul_94_94 : __gen_01_history_1_value);
        number sub_97_99 = switch_96_98 - 1;
        auto max_98_100 = this->maximum(sub_97_99, 0);
        number div_99_101 = (latch_95_97 == 0. ? 0. : max_98_100 / latch_95_97);
        number gen_100_102 = div_99_101;
        number history_1_next_101_103 = fixdenorm(max_98_100);
        number mul_102_104 = gen_100_102 * gen_100_102;
        number bell_trig_103_105 = bell_trig_91_91;
        number mul_105_107 = abs_104_106 * bell_trig_103_105;
        number mul_106_108 = mul_105_107 * this->sr;
        number latch_107_110 = this->gen_01_latch_109_next(mul_106_108, bell_trig_103_105);
        number switch_108_111 = ((bool)(mul_106_108) ? mul_106_108 : __gen_01_history_2_value);
        number sub_109_112 = switch_108_111 - 1;
        auto max_110_113 = this->maximum(sub_109_112, 0);
        number div_111_114 = (latch_107_110 == 0. ? 0. : max_110_113 / latch_107_110);
        number gen_112_115 = div_111_114;
        number history_2_next_113_116 = fixdenorm(max_110_113);
        number mul_114_117 = gen_112_115 * sub_27_25;
        number phasor_116_121 = this->gen_01_phasor_120_next(pass_115_118, 0);
        number mul_117_122 = phasor_116_121 * 0.5;
        number phasor_119_125 = this->gen_01_phasor_124_next(mul_118_123, 0);
        number mul_120_126 = phasor_119_125 * 0.75;
        number float_121_127 = float(1.41);
        number mul_122_128 = pass_115_118 * float_121_127;
        number phasor_123_130 = this->gen_01_phasor_129_next(mul_122_128, 0);
        number mul_124_131 = phasor_123_130 * 2;
        number mul_125_132 = mul_124_131 * 3.14159265358979323846;
        number sin_126_133 = rnbo_sin(mul_125_132);
        number mul_127_134 = sin_126_133 * 1.5;
        number add_128_135 = mul_117_122 + mul_127_134;
        number sin_129_136 = rnbo_sin(add_128_135);
        number mul_130_137 = mul_102_104 * sin_129_136;
        number float_131_138 = float(2.1);
        number mul_132_139 = mul_118_123 * float_131_138;
        number phasor_133_141 = this->gen_01_phasor_140_next(mul_132_139, 0);
        number mul_134_142 = phasor_133_141 * 2;
        number mul_135_143 = mul_134_142 * 3.14159265358979323846;
        number sin_136_144 = rnbo_sin(mul_135_143);
        number mul_137_145 = sin_136_144 * 3;
        number add_138_146 = mul_120_126 + mul_137_145;
        number sin_139_147 = rnbo_sin(add_138_146);
        number mul_140_148 = mul_102_104 * sin_139_147;
        number add_141_149 = mul_130_137 + (mul_114_117 + mul_140_148);
        number mul_142_150 = add_141_149 * 0.7;
        number mul_143_151 = volume_6_2 * mul_142_150;
        number tanh_144_152 = rnbo_tanh(mul_143_151);
        number add_145_153 = tanh_144_152 + tanh_88_87;
        out1[(Index)i] = add_145_153;
        number history_3_next_146_154 = fixdenorm(mix_12_8);
        number history_4_next_147_155 = fixdenorm(mix_85_84);
        __gen_01_history_1_value = history_1_next_101_103;
        __gen_01_history_4_value = history_4_next_147_155;
        __gen_01_history_3_value = history_3_next_146_154;
        __gen_01_history_2_value = history_2_next_113_116;
    }

    this->gen_01_history_3_value = __gen_01_history_3_value;
    this->gen_01_history_4_value = __gen_01_history_4_value;
    this->gen_01_history_1_value = __gen_01_history_1_value;
    this->gen_01_history_2_value = __gen_01_history_2_value;
}

void signalforwarder_01_perform(const SampleValue * input, SampleValue * output, Index n) {
    copySignal(output, input, n);
}

void signalforwarder_02_perform(const SampleValue * input, SampleValue * output, Index n) {
    copySignal(output, input, n);
}

void stackprotect_perform(Index n) {
    RNBO_UNUSED(n);
    auto __stackprotect_count = this->stackprotect_count;
    __stackprotect_count = 0;
    this->stackprotect_count = __stackprotect_count;
}

void param_01_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_01_value;
}

void param_01_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_01_value_set(preset["value"]);
}

number gen_01_history_1_getvalue() {
    return this->gen_01_history_1_value;
}

void gen_01_history_1_setvalue(number val) {
    this->gen_01_history_1_value = val;
}

void gen_01_history_1_reset() {
    this->gen_01_history_1_value = 0;
}

void gen_01_history_1_init() {
    this->gen_01_history_1_value = 0;
}

number gen_01_history_2_getvalue() {
    return this->gen_01_history_2_value;
}

void gen_01_history_2_setvalue(number val) {
    this->gen_01_history_2_value = val;
}

void gen_01_history_2_reset() {
    this->gen_01_history_2_value = 0;
}

void gen_01_history_2_init() {
    this->gen_01_history_2_value = 0;
}

number gen_01_history_3_getvalue() {
    return this->gen_01_history_3_value;
}

void gen_01_history_3_setvalue(number val) {
    this->gen_01_history_3_value = val;
}

void gen_01_history_3_reset() {
    this->gen_01_history_3_value = 0;
}

void gen_01_history_3_init() {
    this->gen_01_history_3_value = 0;
}

number gen_01_history_4_getvalue() {
    return this->gen_01_history_4_value;
}

void gen_01_history_4_setvalue(number val) {
    this->gen_01_history_4_value = val;
}

void gen_01_history_4_reset() {
    this->gen_01_history_4_value = 0;
}

void gen_01_history_4_init() {
    this->gen_01_history_4_value = 0;
}

void gen_01_noise_0_reset() {
    xoshiro_reset(
        systemticks() + this->voice() + this->random(0, 10000),
        this->gen_01_noise_0_state
    );
}

void gen_01_noise_0_init() {
    this->gen_01_noise_0_reset();
}

void gen_01_noise_0_seed(number v) {
    xoshiro_reset(v, this->gen_01_noise_0_state);
}

number gen_01_noise_0_next() {
    return xoshiro_next(this->gen_01_noise_0_state);
}

void gen_01_noise_12_reset() {
    xoshiro_reset(
        systemticks() + this->voice() + this->random(0, 10000),
        this->gen_01_noise_12_state
    );
}

void gen_01_noise_12_init() {
    this->gen_01_noise_12_reset();
}

void gen_01_noise_12_seed(number v) {
    xoshiro_reset(v, this->gen_01_noise_12_state);
}

number gen_01_noise_12_next() {
    return xoshiro_next(this->gen_01_noise_12_state);
}

void gen_01_noise_15_reset() {
    xoshiro_reset(
        systemticks() + this->voice() + this->random(0, 10000),
        this->gen_01_noise_15_state
    );
}

void gen_01_noise_15_init() {
    this->gen_01_noise_15_reset();
}

void gen_01_noise_15_seed(number v) {
    xoshiro_reset(v, this->gen_01_noise_15_state);
}

number gen_01_noise_15_next() {
    return xoshiro_next(this->gen_01_noise_15_state);
}

number gen_01_cycle_38_ph_next(number freq, number reset) {
    RNBO_UNUSED(reset);

    {
        {}
    }

    number pincr = freq * this->gen_01_cycle_38_ph_conv;

    if (this->gen_01_cycle_38_ph_currentPhase < 0.)
        this->gen_01_cycle_38_ph_currentPhase = 1. + this->gen_01_cycle_38_ph_currentPhase;

    if (this->gen_01_cycle_38_ph_currentPhase > 1.)
        this->gen_01_cycle_38_ph_currentPhase = this->gen_01_cycle_38_ph_currentPhase - 1.;

    number tmp = this->gen_01_cycle_38_ph_currentPhase;
    this->gen_01_cycle_38_ph_currentPhase += pincr;
    return tmp;
}

void gen_01_cycle_38_ph_reset() {
    this->gen_01_cycle_38_ph_currentPhase = 0;
}

void gen_01_cycle_38_ph_dspsetup() {
    this->gen_01_cycle_38_ph_conv = (this->sr == 0. ? 0. : (number)1 / this->sr);
}

array<number, 2> gen_01_cycle_38_next(number frequency, number phase_offset) {
    RNBO_UNUSED(phase_offset);

    {
        UInt32 uint_phase;

        {
            uint_phase = this->gen_01_cycle_38_phasei;
        }

        UInt32 idx = (UInt32)(uint32_rshift(uint_phase, 18));
        number frac = ((BinOpInt)((BinOpInt)uint_phase & (BinOpInt)262143)) * 3.81471181759574e-6;
        number y0 = this->gen_01_cycle_38_buffer[(Index)idx];
        number y1 = this->gen_01_cycle_38_buffer[(Index)((BinOpInt)(idx + 1) & (BinOpInt)16383)];
        number y = y0 + frac * (y1 - y0);

        {
            UInt32 pincr = (UInt32)(uint32_trunc(frequency * this->gen_01_cycle_38_f2i));
            this->gen_01_cycle_38_phasei = uint32_add(this->gen_01_cycle_38_phasei, pincr);
        }

        return {y, uint_phase * 0.232830643653869629e-9};
    }
}

void gen_01_cycle_38_dspsetup() {
    this->gen_01_cycle_38_phasei = 0;
    this->gen_01_cycle_38_f2i = (this->sr == 0. ? 0. : (number)4294967296 / this->sr);
    this->gen_01_cycle_38_wrap = (Int)(this->gen_01_cycle_38_buffer->getSize()) - 1;
}

void gen_01_cycle_38_reset() {
    this->gen_01_cycle_38_phasei = 0;
}

void gen_01_cycle_38_bufferUpdated() {
    this->gen_01_cycle_38_wrap = (Int)(this->gen_01_cycle_38_buffer->getSize()) - 1;
}

number gen_01_cycle_41_ph_next(number freq, number reset) {
    RNBO_UNUSED(reset);

    {
        {}
    }

    number pincr = freq * this->gen_01_cycle_41_ph_conv;

    if (this->gen_01_cycle_41_ph_currentPhase < 0.)
        this->gen_01_cycle_41_ph_currentPhase = 1. + this->gen_01_cycle_41_ph_currentPhase;

    if (this->gen_01_cycle_41_ph_currentPhase > 1.)
        this->gen_01_cycle_41_ph_currentPhase = this->gen_01_cycle_41_ph_currentPhase - 1.;

    number tmp = this->gen_01_cycle_41_ph_currentPhase;
    this->gen_01_cycle_41_ph_currentPhase += pincr;
    return tmp;
}

void gen_01_cycle_41_ph_reset() {
    this->gen_01_cycle_41_ph_currentPhase = 0;
}

void gen_01_cycle_41_ph_dspsetup() {
    this->gen_01_cycle_41_ph_conv = (this->sr == 0. ? 0. : (number)1 / this->sr);
}

array<number, 2> gen_01_cycle_41_next(number frequency, number phase_offset) {
    RNBO_UNUSED(phase_offset);

    {
        UInt32 uint_phase;

        {
            uint_phase = this->gen_01_cycle_41_phasei;
        }

        UInt32 idx = (UInt32)(uint32_rshift(uint_phase, 18));
        number frac = ((BinOpInt)((BinOpInt)uint_phase & (BinOpInt)262143)) * 3.81471181759574e-6;
        number y0 = this->gen_01_cycle_41_buffer[(Index)idx];
        number y1 = this->gen_01_cycle_41_buffer[(Index)((BinOpInt)(idx + 1) & (BinOpInt)16383)];
        number y = y0 + frac * (y1 - y0);

        {
            UInt32 pincr = (UInt32)(uint32_trunc(frequency * this->gen_01_cycle_41_f2i));
            this->gen_01_cycle_41_phasei = uint32_add(this->gen_01_cycle_41_phasei, pincr);
        }

        return {y, uint_phase * 0.232830643653869629e-9};
    }
}

void gen_01_cycle_41_dspsetup() {
    this->gen_01_cycle_41_phasei = 0;
    this->gen_01_cycle_41_f2i = (this->sr == 0. ? 0. : (number)4294967296 / this->sr);
    this->gen_01_cycle_41_wrap = (Int)(this->gen_01_cycle_41_buffer->getSize()) - 1;
}

void gen_01_cycle_41_reset() {
    this->gen_01_cycle_41_phasei = 0;
}

void gen_01_cycle_41_bufferUpdated() {
    this->gen_01_cycle_41_wrap = (Int)(this->gen_01_cycle_41_buffer->getSize()) - 1;
}

number gen_01_cycle_44_ph_next(number freq, number reset) {
    RNBO_UNUSED(reset);

    {
        {}
    }

    number pincr = freq * this->gen_01_cycle_44_ph_conv;

    if (this->gen_01_cycle_44_ph_currentPhase < 0.)
        this->gen_01_cycle_44_ph_currentPhase = 1. + this->gen_01_cycle_44_ph_currentPhase;

    if (this->gen_01_cycle_44_ph_currentPhase > 1.)
        this->gen_01_cycle_44_ph_currentPhase = this->gen_01_cycle_44_ph_currentPhase - 1.;

    number tmp = this->gen_01_cycle_44_ph_currentPhase;
    this->gen_01_cycle_44_ph_currentPhase += pincr;
    return tmp;
}

void gen_01_cycle_44_ph_reset() {
    this->gen_01_cycle_44_ph_currentPhase = 0;
}

void gen_01_cycle_44_ph_dspsetup() {
    this->gen_01_cycle_44_ph_conv = (this->sr == 0. ? 0. : (number)1 / this->sr);
}

array<number, 2> gen_01_cycle_44_next(number frequency, number phase_offset) {
    RNBO_UNUSED(phase_offset);

    {
        UInt32 uint_phase;

        {
            uint_phase = this->gen_01_cycle_44_phasei;
        }

        UInt32 idx = (UInt32)(uint32_rshift(uint_phase, 18));
        number frac = ((BinOpInt)((BinOpInt)uint_phase & (BinOpInt)262143)) * 3.81471181759574e-6;
        number y0 = this->gen_01_cycle_44_buffer[(Index)idx];
        number y1 = this->gen_01_cycle_44_buffer[(Index)((BinOpInt)(idx + 1) & (BinOpInt)16383)];
        number y = y0 + frac * (y1 - y0);

        {
            UInt32 pincr = (UInt32)(uint32_trunc(frequency * this->gen_01_cycle_44_f2i));
            this->gen_01_cycle_44_phasei = uint32_add(this->gen_01_cycle_44_phasei, pincr);
        }

        return {y, uint_phase * 0.232830643653869629e-9};
    }
}

void gen_01_cycle_44_dspsetup() {
    this->gen_01_cycle_44_phasei = 0;
    this->gen_01_cycle_44_f2i = (this->sr == 0. ? 0. : (number)4294967296 / this->sr);
    this->gen_01_cycle_44_wrap = (Int)(this->gen_01_cycle_44_buffer->getSize()) - 1;
}

void gen_01_cycle_44_reset() {
    this->gen_01_cycle_44_phasei = 0;
}

void gen_01_cycle_44_bufferUpdated() {
    this->gen_01_cycle_44_wrap = (Int)(this->gen_01_cycle_44_buffer->getSize()) - 1;
}

number gen_01_phasor_60_next(number freq, number reset) {
    RNBO_UNUSED(reset);
    number pincr = freq * this->gen_01_phasor_60_conv;

    if (this->gen_01_phasor_60_currentPhase < 0.)
        this->gen_01_phasor_60_currentPhase = 1. + this->gen_01_phasor_60_currentPhase;

    if (this->gen_01_phasor_60_currentPhase > 1.)
        this->gen_01_phasor_60_currentPhase = this->gen_01_phasor_60_currentPhase - 1.;

    number tmp = this->gen_01_phasor_60_currentPhase;
    this->gen_01_phasor_60_currentPhase += pincr;
    return tmp;
}

void gen_01_phasor_60_reset() {
    this->gen_01_phasor_60_currentPhase = 0;
}

void gen_01_phasor_60_dspsetup() {
    this->gen_01_phasor_60_conv = (this->sr == 0. ? 0. : (number)1 / this->sr);
}

number gen_01_cycle_66_ph_next(number freq, number reset) {
    RNBO_UNUSED(reset);

    {
        {}
    }

    number pincr = freq * this->gen_01_cycle_66_ph_conv;

    if (this->gen_01_cycle_66_ph_currentPhase < 0.)
        this->gen_01_cycle_66_ph_currentPhase = 1. + this->gen_01_cycle_66_ph_currentPhase;

    if (this->gen_01_cycle_66_ph_currentPhase > 1.)
        this->gen_01_cycle_66_ph_currentPhase = this->gen_01_cycle_66_ph_currentPhase - 1.;

    number tmp = this->gen_01_cycle_66_ph_currentPhase;
    this->gen_01_cycle_66_ph_currentPhase += pincr;
    return tmp;
}

void gen_01_cycle_66_ph_reset() {
    this->gen_01_cycle_66_ph_currentPhase = 0;
}

void gen_01_cycle_66_ph_dspsetup() {
    this->gen_01_cycle_66_ph_conv = (this->sr == 0. ? 0. : (number)1 / this->sr);
}

array<number, 2> gen_01_cycle_66_next(number frequency, number phase_offset) {
    RNBO_UNUSED(phase_offset);

    {
        UInt32 uint_phase;

        {
            uint_phase = this->gen_01_cycle_66_phasei;
        }

        UInt32 idx = (UInt32)(uint32_rshift(uint_phase, 18));
        number frac = ((BinOpInt)((BinOpInt)uint_phase & (BinOpInt)262143)) * 3.81471181759574e-6;
        number y0 = this->gen_01_cycle_66_buffer[(Index)idx];
        number y1 = this->gen_01_cycle_66_buffer[(Index)((BinOpInt)(idx + 1) & (BinOpInt)16383)];
        number y = y0 + frac * (y1 - y0);

        {
            UInt32 pincr = (UInt32)(uint32_trunc(frequency * this->gen_01_cycle_66_f2i));
            this->gen_01_cycle_66_phasei = uint32_add(this->gen_01_cycle_66_phasei, pincr);
        }

        return {y, uint_phase * 0.232830643653869629e-9};
    }
}

void gen_01_cycle_66_dspsetup() {
    this->gen_01_cycle_66_phasei = 0;
    this->gen_01_cycle_66_f2i = (this->sr == 0. ? 0. : (number)4294967296 / this->sr);
    this->gen_01_cycle_66_wrap = (Int)(this->gen_01_cycle_66_buffer->getSize()) - 1;
}

void gen_01_cycle_66_reset() {
    this->gen_01_cycle_66_phasei = 0;
}

void gen_01_cycle_66_bufferUpdated() {
    this->gen_01_cycle_66_wrap = (Int)(this->gen_01_cycle_66_buffer->getSize()) - 1;
}

number gen_01_cycle_71_ph_next(number freq, number reset) {
    RNBO_UNUSED(reset);

    {
        {}
    }

    number pincr = freq * this->gen_01_cycle_71_ph_conv;

    if (this->gen_01_cycle_71_ph_currentPhase < 0.)
        this->gen_01_cycle_71_ph_currentPhase = 1. + this->gen_01_cycle_71_ph_currentPhase;

    if (this->gen_01_cycle_71_ph_currentPhase > 1.)
        this->gen_01_cycle_71_ph_currentPhase = this->gen_01_cycle_71_ph_currentPhase - 1.;

    number tmp = this->gen_01_cycle_71_ph_currentPhase;
    this->gen_01_cycle_71_ph_currentPhase += pincr;
    return tmp;
}

void gen_01_cycle_71_ph_reset() {
    this->gen_01_cycle_71_ph_currentPhase = 0;
}

void gen_01_cycle_71_ph_dspsetup() {
    this->gen_01_cycle_71_ph_conv = (this->sr == 0. ? 0. : (number)1 / this->sr);
}

array<number, 2> gen_01_cycle_71_next(number frequency, number phase_offset) {
    RNBO_UNUSED(phase_offset);

    {
        UInt32 uint_phase;

        {
            uint_phase = this->gen_01_cycle_71_phasei;
        }

        UInt32 idx = (UInt32)(uint32_rshift(uint_phase, 18));
        number frac = ((BinOpInt)((BinOpInt)uint_phase & (BinOpInt)262143)) * 3.81471181759574e-6;
        number y0 = this->gen_01_cycle_71_buffer[(Index)idx];
        number y1 = this->gen_01_cycle_71_buffer[(Index)((BinOpInt)(idx + 1) & (BinOpInt)16383)];
        number y = y0 + frac * (y1 - y0);

        {
            UInt32 pincr = (UInt32)(uint32_trunc(frequency * this->gen_01_cycle_71_f2i));
            this->gen_01_cycle_71_phasei = uint32_add(this->gen_01_cycle_71_phasei, pincr);
        }

        return {y, uint_phase * 0.232830643653869629e-9};
    }
}

void gen_01_cycle_71_dspsetup() {
    this->gen_01_cycle_71_phasei = 0;
    this->gen_01_cycle_71_f2i = (this->sr == 0. ? 0. : (number)4294967296 / this->sr);
    this->gen_01_cycle_71_wrap = (Int)(this->gen_01_cycle_71_buffer->getSize()) - 1;
}

void gen_01_cycle_71_reset() {
    this->gen_01_cycle_71_phasei = 0;
}

void gen_01_cycle_71_bufferUpdated() {
    this->gen_01_cycle_71_wrap = (Int)(this->gen_01_cycle_71_buffer->getSize()) - 1;
}

number gen_01_cycle_76_ph_next(number freq, number reset) {
    RNBO_UNUSED(reset);

    {
        {}
    }

    number pincr = freq * this->gen_01_cycle_76_ph_conv;

    if (this->gen_01_cycle_76_ph_currentPhase < 0.)
        this->gen_01_cycle_76_ph_currentPhase = 1. + this->gen_01_cycle_76_ph_currentPhase;

    if (this->gen_01_cycle_76_ph_currentPhase > 1.)
        this->gen_01_cycle_76_ph_currentPhase = this->gen_01_cycle_76_ph_currentPhase - 1.;

    number tmp = this->gen_01_cycle_76_ph_currentPhase;
    this->gen_01_cycle_76_ph_currentPhase += pincr;
    return tmp;
}

void gen_01_cycle_76_ph_reset() {
    this->gen_01_cycle_76_ph_currentPhase = 0;
}

void gen_01_cycle_76_ph_dspsetup() {
    this->gen_01_cycle_76_ph_conv = (this->sr == 0. ? 0. : (number)1 / this->sr);
}

array<number, 2> gen_01_cycle_76_next(number frequency, number phase_offset) {
    RNBO_UNUSED(phase_offset);

    {
        UInt32 uint_phase;

        {
            uint_phase = this->gen_01_cycle_76_phasei;
        }

        UInt32 idx = (UInt32)(uint32_rshift(uint_phase, 18));
        number frac = ((BinOpInt)((BinOpInt)uint_phase & (BinOpInt)262143)) * 3.81471181759574e-6;
        number y0 = this->gen_01_cycle_76_buffer[(Index)idx];
        number y1 = this->gen_01_cycle_76_buffer[(Index)((BinOpInt)(idx + 1) & (BinOpInt)16383)];
        number y = y0 + frac * (y1 - y0);

        {
            UInt32 pincr = (UInt32)(uint32_trunc(frequency * this->gen_01_cycle_76_f2i));
            this->gen_01_cycle_76_phasei = uint32_add(this->gen_01_cycle_76_phasei, pincr);
        }

        return {y, uint_phase * 0.232830643653869629e-9};
    }
}

void gen_01_cycle_76_dspsetup() {
    this->gen_01_cycle_76_phasei = 0;
    this->gen_01_cycle_76_f2i = (this->sr == 0. ? 0. : (number)4294967296 / this->sr);
    this->gen_01_cycle_76_wrap = (Int)(this->gen_01_cycle_76_buffer->getSize()) - 1;
}

void gen_01_cycle_76_reset() {
    this->gen_01_cycle_76_phasei = 0;
}

void gen_01_cycle_76_bufferUpdated() {
    this->gen_01_cycle_76_wrap = (Int)(this->gen_01_cycle_76_buffer->getSize()) - 1;
}

number gen_01_change_88_next(number x) {
    number temp = x - this->gen_01_change_88_prev;
    this->gen_01_change_88_prev = x;
    return (temp > 0. ? 1. : (temp < 0. ? -1. : 0));
}

void gen_01_change_88_init() {
    this->gen_01_change_88_prev = 0;
}

void gen_01_change_88_reset() {
    this->gen_01_change_88_prev = 0;
}

number gen_01_latch_96_next(number x, number control) {
    if (control != 0.) {
        this->gen_01_latch_96_value = x;
    }

    return this->gen_01_latch_96_value;
}

void gen_01_latch_96_dspsetup() {
    this->gen_01_latch_96_reset();
}

void gen_01_latch_96_init() {
    this->gen_01_latch_96_reset();
}

void gen_01_latch_96_reset() {
    this->gen_01_latch_96_value = 0;
}

number gen_01_latch_109_next(number x, number control) {
    if (control != 0.) {
        this->gen_01_latch_109_value = x;
    }

    return this->gen_01_latch_109_value;
}

void gen_01_latch_109_dspsetup() {
    this->gen_01_latch_109_reset();
}

void gen_01_latch_109_init() {
    this->gen_01_latch_109_reset();
}

void gen_01_latch_109_reset() {
    this->gen_01_latch_109_value = 0;
}

number gen_01_phasor_120_next(number freq, number reset) {
    RNBO_UNUSED(reset);
    number pincr = freq * this->gen_01_phasor_120_conv;

    if (this->gen_01_phasor_120_currentPhase < 0.)
        this->gen_01_phasor_120_currentPhase = 1. + this->gen_01_phasor_120_currentPhase;

    if (this->gen_01_phasor_120_currentPhase > 1.)
        this->gen_01_phasor_120_currentPhase = this->gen_01_phasor_120_currentPhase - 1.;

    number tmp = this->gen_01_phasor_120_currentPhase;
    this->gen_01_phasor_120_currentPhase += pincr;
    return tmp;
}

void gen_01_phasor_120_reset() {
    this->gen_01_phasor_120_currentPhase = 0;
}

void gen_01_phasor_120_dspsetup() {
    this->gen_01_phasor_120_conv = (this->sr == 0. ? 0. : (number)1 / this->sr);
}

number gen_01_phasor_124_next(number freq, number reset) {
    RNBO_UNUSED(reset);
    number pincr = freq * this->gen_01_phasor_124_conv;

    if (this->gen_01_phasor_124_currentPhase < 0.)
        this->gen_01_phasor_124_currentPhase = 1. + this->gen_01_phasor_124_currentPhase;

    if (this->gen_01_phasor_124_currentPhase > 1.)
        this->gen_01_phasor_124_currentPhase = this->gen_01_phasor_124_currentPhase - 1.;

    number tmp = this->gen_01_phasor_124_currentPhase;
    this->gen_01_phasor_124_currentPhase += pincr;
    return tmp;
}

void gen_01_phasor_124_reset() {
    this->gen_01_phasor_124_currentPhase = 0;
}

void gen_01_phasor_124_dspsetup() {
    this->gen_01_phasor_124_conv = (this->sr == 0. ? 0. : (number)1 / this->sr);
}

number gen_01_phasor_129_next(number freq, number reset) {
    RNBO_UNUSED(reset);
    number pincr = freq * this->gen_01_phasor_129_conv;

    if (this->gen_01_phasor_129_currentPhase < 0.)
        this->gen_01_phasor_129_currentPhase = 1. + this->gen_01_phasor_129_currentPhase;

    if (this->gen_01_phasor_129_currentPhase > 1.)
        this->gen_01_phasor_129_currentPhase = this->gen_01_phasor_129_currentPhase - 1.;

    number tmp = this->gen_01_phasor_129_currentPhase;
    this->gen_01_phasor_129_currentPhase += pincr;
    return tmp;
}

void gen_01_phasor_129_reset() {
    this->gen_01_phasor_129_currentPhase = 0;
}

void gen_01_phasor_129_dspsetup() {
    this->gen_01_phasor_129_conv = (this->sr == 0. ? 0. : (number)1 / this->sr);
}

number gen_01_phasor_140_next(number freq, number reset) {
    RNBO_UNUSED(reset);
    number pincr = freq * this->gen_01_phasor_140_conv;

    if (this->gen_01_phasor_140_currentPhase < 0.)
        this->gen_01_phasor_140_currentPhase = 1. + this->gen_01_phasor_140_currentPhase;

    if (this->gen_01_phasor_140_currentPhase > 1.)
        this->gen_01_phasor_140_currentPhase = this->gen_01_phasor_140_currentPhase - 1.;

    number tmp = this->gen_01_phasor_140_currentPhase;
    this->gen_01_phasor_140_currentPhase += pincr;
    return tmp;
}

void gen_01_phasor_140_reset() {
    this->gen_01_phasor_140_currentPhase = 0;
}

void gen_01_phasor_140_dspsetup() {
    this->gen_01_phasor_140_conv = (this->sr == 0. ? 0. : (number)1 / this->sr);
}

void gen_01_dspsetup(bool force) {
    if ((bool)(this->gen_01_setupDone) && (bool)(!(bool)(force)))
        return;

    this->gen_01_setupDone = true;
    this->gen_01_cycle_38_ph_dspsetup();
    this->gen_01_cycle_38_dspsetup();
    this->gen_01_cycle_41_ph_dspsetup();
    this->gen_01_cycle_41_dspsetup();
    this->gen_01_cycle_44_ph_dspsetup();
    this->gen_01_cycle_44_dspsetup();
    this->gen_01_phasor_60_dspsetup();
    this->gen_01_cycle_66_ph_dspsetup();
    this->gen_01_cycle_66_dspsetup();
    this->gen_01_cycle_71_ph_dspsetup();
    this->gen_01_cycle_71_dspsetup();
    this->gen_01_cycle_76_ph_dspsetup();
    this->gen_01_cycle_76_dspsetup();
    this->gen_01_latch_96_dspsetup();
    this->gen_01_latch_109_dspsetup();
    this->gen_01_phasor_120_dspsetup();
    this->gen_01_phasor_124_dspsetup();
    this->gen_01_phasor_129_dspsetup();
    this->gen_01_phasor_140_dspsetup();
}

void param_02_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_02_value;
}

void param_02_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_02_value_set(preset["value"]);
}

void param_03_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_03_value;
}

void param_03_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_03_value_set(preset["value"]);
}

void param_04_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_04_value;
}

void param_04_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_04_value_set(preset["value"]);
}

void param_05_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_05_value;
}

void param_05_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_05_value_set(preset["value"]);
}

void param_06_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_06_value;
}

void param_06_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_06_value_set(preset["value"]);
}

void param_07_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_07_value;
}

void param_07_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_07_value_set(preset["value"]);
}

void globaltransport_advance() {}

void globaltransport_dspsetup(bool ) {}

bool stackprotect_check() {
    this->stackprotect_count++;

    if (this->stackprotect_count > 128) {
        console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
        return true;
    }

    return false;
}

Index getPatcherSerial() const {
    return 0;
}

void sendParameter(ParameterIndex index, bool ignoreValue) {
    this->getEngine()->notifyParameterValueChanged(index, (ignoreValue ? 0 : this->getParameterValue(index)), ignoreValue);
}

void scheduleParamInit(ParameterIndex index, Index order) {
    this->paramInitIndices->push(index);
    this->paramInitOrder->push(order);
}

void processParamInitEvents() {
    this->listquicksort(
        this->paramInitOrder,
        this->paramInitIndices,
        0,
        (int)(this->paramInitOrder->length - 1),
        true
    );

    for (Index i = 0; i < this->paramInitOrder->length; i++) {
        this->getEngine()->scheduleParameterBang(this->paramInitIndices[i], 0);
    }
}

void updateTime(MillisecondTime time, EXTERNALENGINE* engine, bool inProcess = false) {
    RNBO_UNUSED(inProcess);
    RNBO_UNUSED(engine);
    this->_currentTime = time;
    auto offset = rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr));

    if (offset >= (SampleIndex)(this->vs))
        offset = (SampleIndex)(this->vs) - 1;

    if (offset < 0)
        offset = 0;

    this->sampleOffsetIntoNextAudioBuffer = (Index)(offset);
}

void assign_defaults()
{
    param_01_value = 0;
    gen_01_in1 = 0;
    gen_01_speed_min = 0;
    gen_01_speed_max = 0;
    gen_01_ding_duration = 0;
    gen_01_speed = 0;
    gen_01_bell_trig = 0;
    gen_01_volume_out = 0;
    gen_01_clack_duration = 0;
    param_02_value = 0;
    param_03_value = 0;
    param_04_value = 0;
    param_05_value = 0;
    param_06_value = 0;
    param_07_value = 0;
    _currentTime = 0;
    audioProcessSampleCount = 0;
    sampleOffsetIntoNextAudioBuffer = 0;
    zeroBuffer = nullptr;
    dummyBuffer = nullptr;
    signals[0] = nullptr;
    didAllocateSignals = 0;
    vs = 0;
    maxvs = 0;
    sr = 44100;
    invsr = 0.000022675736961451248;
    param_01_lastValue = 0;
    gen_01_history_1_value = 0;
    gen_01_history_2_value = 0;
    gen_01_history_3_value = 0;
    gen_01_history_4_value = 0;
    gen_01_cycle_38_ph_currentPhase = 0;
    gen_01_cycle_38_ph_conv = 0;
    gen_01_cycle_38_wrap = 0;
    gen_01_cycle_41_ph_currentPhase = 0;
    gen_01_cycle_41_ph_conv = 0;
    gen_01_cycle_41_wrap = 0;
    gen_01_cycle_44_ph_currentPhase = 0;
    gen_01_cycle_44_ph_conv = 0;
    gen_01_cycle_44_wrap = 0;
    gen_01_phasor_60_currentPhase = 0;
    gen_01_phasor_60_conv = 0;
    gen_01_cycle_66_ph_currentPhase = 0;
    gen_01_cycle_66_ph_conv = 0;
    gen_01_cycle_66_wrap = 0;
    gen_01_cycle_71_ph_currentPhase = 0;
    gen_01_cycle_71_ph_conv = 0;
    gen_01_cycle_71_wrap = 0;
    gen_01_cycle_76_ph_currentPhase = 0;
    gen_01_cycle_76_ph_conv = 0;
    gen_01_cycle_76_wrap = 0;
    gen_01_change_88_prev = 0;
    gen_01_latch_96_value = 0;
    gen_01_latch_109_value = 0;
    gen_01_phasor_120_currentPhase = 0;
    gen_01_phasor_120_conv = 0;
    gen_01_phasor_124_currentPhase = 0;
    gen_01_phasor_124_conv = 0;
    gen_01_phasor_129_currentPhase = 0;
    gen_01_phasor_129_conv = 0;
    gen_01_phasor_140_currentPhase = 0;
    gen_01_phasor_140_conv = 0;
    gen_01_setupDone = false;
    param_02_lastValue = 0;
    param_03_lastValue = 0;
    param_04_lastValue = 0;
    param_05_lastValue = 0;
    param_06_lastValue = 0;
    param_07_lastValue = 0;
    globaltransport_tempo = nullptr;
    globaltransport_state = nullptr;
    stackprotect_count = 0;
    _voiceIndex = 0;
    _noteNumber = 0;
    isMuted = 1;
}

    // data ref strings
    struct DataRefStrings {
    	static constexpr auto& name0 = "RNBODefaultSinus";
    	static constexpr auto& file0 = "";
    	static constexpr auto& tag0 = "buffer~";
    	DataRefStrings* operator->() { return this; }
    	const DataRefStrings* operator->() const { return this; }
    };

    DataRefStrings dataRefStrings;

// member variables

    number param_01_value;
    number gen_01_in1;
    number gen_01_speed_min;
    number gen_01_speed_max;
    number gen_01_ding_duration;
    number gen_01_speed;
    number gen_01_bell_trig;
    number gen_01_volume_out;
    number gen_01_clack_duration;
    number param_02_value;
    number param_03_value;
    number param_04_value;
    number param_05_value;
    number param_06_value;
    number param_07_value;
    MillisecondTime _currentTime;
    ENGINE _internalEngine;
    UInt64 audioProcessSampleCount;
    Index sampleOffsetIntoNextAudioBuffer;
    signal zeroBuffer;
    signal dummyBuffer;
    SampleValue * signals[1];
    bool didAllocateSignals;
    Index vs;
    Index maxvs;
    number sr;
    number invsr;
    number param_01_lastValue;
    number gen_01_history_1_value;
    number gen_01_history_2_value;
    number gen_01_history_3_value;
    number gen_01_history_4_value;
    UInt gen_01_noise_0_state[4] = { };
    UInt gen_01_noise_12_state[4] = { };
    UInt gen_01_noise_15_state[4] = { };
    number gen_01_cycle_38_ph_currentPhase;
    number gen_01_cycle_38_ph_conv;
    SampleBufferRef gen_01_cycle_38_buffer;
    Int gen_01_cycle_38_wrap;
    UInt32 gen_01_cycle_38_phasei;
    SampleValue gen_01_cycle_38_f2i;
    number gen_01_cycle_41_ph_currentPhase;
    number gen_01_cycle_41_ph_conv;
    SampleBufferRef gen_01_cycle_41_buffer;
    Int gen_01_cycle_41_wrap;
    UInt32 gen_01_cycle_41_phasei;
    SampleValue gen_01_cycle_41_f2i;
    number gen_01_cycle_44_ph_currentPhase;
    number gen_01_cycle_44_ph_conv;
    SampleBufferRef gen_01_cycle_44_buffer;
    Int gen_01_cycle_44_wrap;
    UInt32 gen_01_cycle_44_phasei;
    SampleValue gen_01_cycle_44_f2i;
    number gen_01_phasor_60_currentPhase;
    number gen_01_phasor_60_conv;
    number gen_01_cycle_66_ph_currentPhase;
    number gen_01_cycle_66_ph_conv;
    SampleBufferRef gen_01_cycle_66_buffer;
    Int gen_01_cycle_66_wrap;
    UInt32 gen_01_cycle_66_phasei;
    SampleValue gen_01_cycle_66_f2i;
    number gen_01_cycle_71_ph_currentPhase;
    number gen_01_cycle_71_ph_conv;
    SampleBufferRef gen_01_cycle_71_buffer;
    Int gen_01_cycle_71_wrap;
    UInt32 gen_01_cycle_71_phasei;
    SampleValue gen_01_cycle_71_f2i;
    number gen_01_cycle_76_ph_currentPhase;
    number gen_01_cycle_76_ph_conv;
    SampleBufferRef gen_01_cycle_76_buffer;
    Int gen_01_cycle_76_wrap;
    UInt32 gen_01_cycle_76_phasei;
    SampleValue gen_01_cycle_76_f2i;
    number gen_01_change_88_prev;
    number gen_01_latch_96_value;
    number gen_01_latch_109_value;
    number gen_01_phasor_120_currentPhase;
    number gen_01_phasor_120_conv;
    number gen_01_phasor_124_currentPhase;
    number gen_01_phasor_124_conv;
    number gen_01_phasor_129_currentPhase;
    number gen_01_phasor_129_conv;
    number gen_01_phasor_140_currentPhase;
    number gen_01_phasor_140_conv;
    bool gen_01_setupDone;
    number param_02_lastValue;
    number param_03_lastValue;
    number param_04_lastValue;
    number param_05_lastValue;
    number param_06_lastValue;
    number param_07_lastValue;
    signal globaltransport_tempo;
    signal globaltransport_state;
    number stackprotect_count;
    DataRef RNBODefaultSinus;
    Index _voiceIndex;
    Int _noteNumber;
    Index isMuted;
    indexlist paramInitIndices;
    indexlist paramInitOrder;
    bool _isInitialized = false;
};

static PatcherInterface* creaternbomatic()
{
    return new rnbomatic<EXTERNALENGINE>();
}

#ifndef RNBO_NO_PATCHERFACTORY
extern "C" PatcherFactoryFunctionPtr GetPatcherFactoryFunction()
#else
extern "C" PatcherFactoryFunctionPtr rnbomaticFactoryFunction()
#endif
{
    return creaternbomatic;
}

#ifndef RNBO_NO_PATCHERFACTORY
extern "C" void SetLogger(Logger* logger)
#else
void rnbomaticSetLogger(Logger* logger)
#endif
{
    console = logger;
}

} // end RNBO namespace

